# Spring Chat

A real-time chat app built with Spring Boot, WebSocket (STOMP), and a single-page web UI.

## Requirements

- Java 17 or newer
- Maven 3.8 or newer
- curl and a bash-compatible shell (for `server.sh`)

## Quick start

```sh
./server.sh          # start on http://localhost:8080 and open the > prompt
./server.sh 9090     # start on a different port
./server.sh help     # show the script help
```

Open the address in two browser windows (or one normal and one private window), sign up with two accounts, add each other as contacts, and start chatting.

You can also run `com.example.chat.Main` from your IDE, or run `mvn spring-boot:run`. In that case the terminal prompt is not available, but the admin commands can still be run from the Java console (see below).

## The `>` prompt

`./server.sh` starts the server in the background. Server output goes to `server.log`. Type commands at the prompt:

| Command | What it does |
| --- | --- |
| `help` or `?` | Show the command list |
| `ban <name>` | Ban a user. They cannot log in or sign up with that name, and their active sessions end |
| `unban <name>` | Remove a ban |
| `admin add <name>` | Give a user admin rights |
| `admin remove <name>` | Remove admin rights |
| `admin list` | Show all admins |
| `stop` | Stop the server |
| `exit` | Stop the server and close the prompt (Ctrl+D also works) |

Unknown commands print `Command not found`.

To make yourself an admin, sign up in the app first, then run `admin add <your-username>` at the prompt.

## Features

**Accounts**
- Sign up, log in, log out, delete account
- Profile view with display name, bio, and a profile picture (upload or remove)
- Dark mode, saved in the browser

**Contacts and groups**
- Add and delete contacts, search contacts and groups
- Create groups, copy a group invite link, and join with the link

**Messages**
- Text messages with links; links can open in an in-app browser panel
- Images, GIFs, videos, and files, each with preview and save
- Sending and failed states, with Retry and Dismiss
- Read text and read code aloud (browser speech)

**Video player**
- Custom controls: play/pause, seek bar, time, volume, mute, playback speed (0.5x to 2x), save, and fullscreen
- Keyboard: Space or K (play/pause), arrows (seek 5 seconds), M (mute), F (fullscreen), S (save), < and > (speed)

**Files**
- View text files (.txt, .text, .md) and code files (.py, .js, .mjs, .cjs, .css, .html, .htm, .xml, .svg, .java)
- Animated upload and download progress with Cancel

**Moderation**
- Report a contact for a ban (any user, one report per person)
- Admins review reports in the ban panel and can ban or dismiss them
- Admins can ban a contact directly from their chat header
- Admins manage bans from the sidebar ban panel

**Layout**
- Mobile layout on narrow screens, PC layout on wide screens, chosen automatically

**Errors**
- Unknown pages show a 404 screen
- Invalid invite links show the same screen with the reason

## Project layout

```
server.sh                      start the server and open the > prompt
pom.xml                        Maven build (Spring Boot 3.3.5, Java 17)
src/main/java/com/example/chat/
  Main.java                    entry point
  config/WebSocketConfig.java  STOMP endpoint at /ws
  controller/                  REST and WebSocket endpoints
  service/Store.java           in-memory data store
  service/CommandConsole.java  server commands (terminal and admin endpoint)
src/main/resources/
  application.properties
  static/index.html            the whole web app (HTML, CSS, JavaScript)
```

## API overview

| Area | Endpoints |
| --- | --- |
| Auth and profile | `POST /api/auth/signup`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET/PUT/DELETE /api/me`, `PUT/DELETE /api/me/avatar` |
| Contacts | `GET/POST /api/contacts`, `DELETE /api/contacts/{username}` |
| Groups | `GET/POST /api/groups`, `GET /api/groups/{id}/link`, `POST /api/groups/join/{code}` |
| Messages | `GET /api/messages?room=...`, WebSocket `/app/chat.send`, subscribe `/topic/room/{roomId}` |
| Files | `POST /api/files`, `GET /api/files/{id}` (add `?download=true` to save) |
| Reports | `POST /api/reports`, `GET /api/reports` (admin), `DELETE /api/reports/{id}` (admin) |
| Bans | `GET/POST /api/bans` (admin), `DELETE /api/bans/{username}` (admin) |
| Server commands | `POST /api/admin/command` (local machine only, needs the admin token) |

## Configuration

`application.properties` sets the port, upload size limit (100 MB), and two admin settings:

- `chat.admin-token`: set by `server.sh` at startup. Leave it empty to disable the HTTP admin endpoint.
- `chat.console.enabled`: `true` enables the Java terminal console. `server.sh` turns it off so the `>` prompt is the only input.

## Limitations

- Data is kept in memory. Accounts, messages, groups, and bans are lost when the server stops. Uploaded files stay in `./uploads`.
- Passwords use unsalted SHA-256. For production, switch to BCrypt and add Spring Security.
- File URLs are unguessable UUIDs, but anyone with the link can open the file. Chat subscriptions are not access-checked on the server side.
- Some websites block being shown inside another page. The in-app browser then shows an "Open in new tab" button.
- Fullscreen video may be limited on some iPhone browsers.
